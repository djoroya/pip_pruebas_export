from my_package.operator import operator

def operator_export():
    print("Hello World")
    print(operator())
